<?php
class config {
	
    public static function DbConnect() {
        $DB_host = "localhost";
        $DB_user = "fadama";
        $DB_pass = "F4d4m4!";
        $DB_name = "fadama";
        $connection = mysql_connect($DB_host, $DB_user, $DB_pass);
        if (!$connection)
            echo 'Failed to obtain a succesful connection to the localHost';
        mysql_select_db($DB_name, $connection) or die(mysql_error());
        return $connection;
    }

    public static function executeQuery($sql) {
        $result = mysql_query($sql) or die("Error in Selecting " . mysql_error());
        return $result;
    }

    public static function login($username, $password) {

        self::DbConnect();
        $username = self::clean($username);
        $password = self::clean($password);
        $sql = "select ID,Name,Privilege,UserName  from users where UserName='$username' and password='$password'";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
 public static function verifyPassword($cpassword) {
		self::DbConnect();
		$cpassword = self::clean($cpassword);
        $sql = "select password  from users where password='$cpassword'";
        $result = self::executeQuery($sql);
		$myresult=null;
        while ($row = mysql_fetch_assoc($result)) {
            $myresult= $row['password'];
        }
		mysql_close();
        mysql_free_result($result);
        return $myresult;
    }
	
	public static function changePassword( $id,$rnpassword,$username,$UserPhone) {
		self::DbConnect();
		$id = self::clean($id);
		$rnpassword = self::clean($rnpassword);
		$username = self::clean($username);
		$UserPhone = self::clean($UserPhone);
        $sql = "update  users set password='$rnpassword' where ID=$id";
        self::executeQuery($sql);
		$msg="Dear {$username},your password was successfully changed.Your new password is {$rnpassword}";
		$sql2=" insert into  outMessages(messageID,messageContent,destAddress,sourceAddress,statusID,dateInserted,no_Of_Retry,max_Send,bucketID,dateModified)  values('','$msg','$UserPhone','FADAMA/FIKS','7',now(),'0','0','0',now())";
        self::executeQuery($sql2);
    }
    public static function fetchTotalFarmers() {
        $sql = "select format(count(*),0) AS totalnumber from farmers";
         self::DbConnect();
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
		mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function fetchTotalFCA() {
        $sql = "select format(count(*),0) AS totalnumber from fca";
         self::DbConnect();
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
      
        return $emparray;
    }

    public static function fetchStateFCA($stateID) {
         self::DbConnect();
        $stateID = self::clean($stateID);
        $sql = "select format(count(*),0) AS totalnumber from fca where stateID='$stateID'";
         self::DbConnect();
        $result = self::executeQuery($sql);
		$myresult=null;
        while ($row = mysql_fetch_assoc($result)) {
            $myresult = $row['totalnumber'];
        }
        mysql_close();
        
        return $myresult;
    }

    public static function fetchTotalFUG() {
        $sql = "select format(count(*),0) AS totalnumber from fug";
         self::DbConnect();
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function fetchStateFUG($stateID) {
         self::DbConnect();
        $stateID = self::clean($stateID);
        $sql = "select format(count(*),0) AS totalnumber from fug where FCAID in"
                . "(select ID from fca where stateID='$stateID')";

        $result = self::executeQuery($sql);
        while ($row = mysql_fetch_assoc($result)) {
            $myresult = $row['totalnumber'];
        }

        mysql_free_result($result);
        mysql_close();
        return $myresult;
    }

    public static function animalcount() {
        $sql = "select format(count(*),0) AS totalnumber from animalhusbandry";
         self::DbConnect();
        $result = self::executeQuery($sql);
        while ($row = mysql_fetch_assoc($result)) {
            $myresult = $row['totalnumber'];
        }

        mysql_free_result($result);
        mysql_close();
        return $myresult;
    }

    public static function cropCount() {
        $sql = "select format(count(*),0) AS totalnumber from crops";
         self::DbConnect();
        $result = self::executeQuery($sql);
        while ($row = mysql_fetch_assoc($result)) {
            $myresult = $row['totalnumber'];
        }

        mysql_close();
        mysql_free_result($result);
        return $myresult;
    }

    public static function marketCount() {
        $sql = "select format(count(*),0) AS totalnumber from markets";
         self::DbConnect();
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_array($result)) {
            $myresult = $row['totalnumber'];
        }
        mysql_close();
        mysql_free_result($result);
        return $myresult;
    }

    public static function agroBusinessCount() {
        $sql = "select format(count(*),0) AS totalnumber from agrobusiness";
         self::DbConnect();
        $result = self::executeQuery($sql);
        while ($row = mysql_fetch_array($result)) {
            $myresult = $row['totalnumber'];
        }
        mysql_close();

        return $myresult;
    }

    public static function fetchLangName($languageID) {
         self::DbConnect();
        $languageID = self::clean($languageID);
        $sql = "select Name AS Name from languages where ID='$languageID'";
        $result = self::executeQuery($sql);
        $myresult = null;
        while ($row = mysql_fetch_assoc($result)) {
            $myresult = $row['Name'];
        }
        mysql_close();
        mysql_free_result($result);
        return $myresult;
    }

    public static function fetchstateName($stateID) {
         self::DbConnect();
        $stateID = self::clean($stateID);
        $sql = "select stateName AS Name from  states where stateID='$stateID'";
        $result = self::executeQuery($sql);
        $myresult = null;
        while ($row = mysql_fetch_assoc($result)) {
            $myresult = $row['Name'];
        }
        mysql_close();
        mysql_free_result($result);
        return $myresult;
    }
    
    

    public static function fetchlgaName($lgaID) {
         self::DbConnect();
        $lgaID = self::clean($lgaID);
        $sql = "select lgaName AS Name from lga where lgaID='$lgaID'";
        $result = self::executeQuery($sql);
        $myresult = null;
        while ($row = mysql_fetch_assoc($result)) {
            $myresult = $row['Name'];
        }
        mysql_close();
        mysql_free_result($result);
        return $myresult;
    }

    public static function fetchfcaName($fcaID) {
         self::DbConnect();
        $fcaID = self::clean($fcaID);
        $sql = "select Name  from fca where ID='$fcaID'";
        $result = self::executeQuery($sql);
        $myresult = null;
        while ($row = mysql_fetch_assoc($result)) {
            $myresult = $row['Name'];
        }
        mysql_close();
        mysql_free_result($result);
        return $myresult;
    }

    public static function checkFarmersRecord($phoneNo) {
         self::DbConnect();
        $phoneNo = self::clean($phoneNo);
        $sql = "select count(*) total  from farmers where MSISDN='$phoneNo'";
        $result = self::executeQuery($sql);
        $myresult = null;
        while ($row = mysql_fetch_assoc($result)) {
            $myresult = $row['total'];
        }
        mysql_close();
        mysql_free_result($result);
        return $myresult;
    }
    public static function checkFcaPhoneNo($phoneNo ) {
         self::DbConnect();
        $phoneNo = self::clean($phoneNo);
        $sql = "select count(*) total  from fca where groupPhoneNo='$phoneNo'  ";
        $result = self::executeQuery($sql);
        $myresult = null;
        while ($row = mysql_fetch_assoc($result)) {
            $myresult = $row['total'];
        }
        mysql_close();
        mysql_free_result($result);
        return $myresult;
    } 
     public static function checkuserPhoneNo($phoneNo ) {
         self::DbConnect();
        $phoneNo = self::clean($phoneNo);
        $sql = "select count(*) total  from users where UserName='$phoneNo'  ";
        $result = self::executeQuery($sql);
        $myresult = null;
        while ($row = mysql_fetch_assoc($result)) {
            $myresult = $row['total'];
        }
        mysql_close();
        mysql_free_result($result);
        return $myresult;
    }
    public static function fetchuserID($MSISDN) {
        $MSISDN = self::clean($MSISDN);
        $sql = "select ID from users where UserName='$MSISDN'";
        $result = self::executeQuery($sql);
        $myResult;
        while ($row = mysql_fetch_row($result)) {
            $myResult = $row[0];
        }
        return $myResult;
    }
    public static function checkFugPhoneNo($phoneNo ) {
         self::DbConnect();
        $phoneNo = self::clean($phoneNo);
        $sql = "select count(*) total  from fug where groupPhoneNo='$phoneNo'  ";
        $result = self::executeQuery($sql);
        $myresult = null;
        while ($row = mysql_fetch_assoc($result)) {
            $myresult = $row['total'];
        }
        mysql_close();
        mysql_free_result($result);
        return $myresult;
    }
    public static function  checkFcaName($name) {
         self::DbConnect();
        $name = self::clean($name);
        $sql = "select count(*) total  from farmers where Name='$name'";
        $result = self::executeQuery($sql);
        $myresult = null;
        while ($row = mysql_fetch_assoc($result)) {
            $myresult = $row['total'];
        }
        mysql_close();
        mysql_free_result($result);
        return $myresult;
    }
    public static function fetchfugName($fugID) {
         self::DbConnect();
        $fugID = self::clean($fugID);
        $sql = "select Name  from fug where ID='$fugID'";
        $result = self::executeQuery($sql);
        $myresult = null;
        while ($row = mysql_fetch_assoc($result)) {
            $myresult = $row['Name'];
        }
        mysql_close();
        mysql_free_result($result);
        return $myresult;
    }

    public static function fetchmarketName($marketID) {
         self::DbConnect();
        $marketID = self::clean($marketID);
        $sql = "select Name from markets where ID='$marketID'";
        $result = self::executeQuery($sql);
        $myresult = null;
        while ($row = mysql_fetch_assoc($result)) {
            $myresult = $row['Name'];
        }
        mysql_close();
        mysql_free_result($result);
        return $myresult;
    }

    public static function fetchAnimalHusband($farmerID) {
         self::DbConnect();
        $farmerID = self::clean($farmerID);
        $sql = "select  distinct a.Name from animalhusbandry a, farmeranimalhusbandry fa  where fa.farmerID='$farmerID' and fa.animalhusbandryID=a.ID";
        $result = self::executeQuery($sql);
        $myresult = array();
        while ($row = mysql_fetch_assoc($result)) {
            $myresult[] = $row['Name'];
        }
        mysql_close();
        mysql_free_result($result);
        return $myresult;
    }

    public static function fetchfarmerCrops($farmerID) {
         self::DbConnect();
        $farmerID = self::clean($farmerID);
        $sql = "select  distinct c.Name from crops c, farmercrops fc  where fc.farmerID='$farmerID' and fc.cropID=c.ID";
        $result = self::executeQuery($sql);
        $myresult = array();
        while ($row = mysql_fetch_assoc($result)) {
            $myresult[] = $row['Name'];
        }
        mysql_close();
        mysql_free_result($result);
        return $myresult;
    }

    public static function statefarmerCount() {
        $sql = "select s.stateName as name,count(*) AS value from farmers f, states s where "
                . "f.stateID=s.stateID GROUP by s.stateName";
         self::DbConnect();
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function stateIDfarmerCount() {
        $sql = "select f.stateID as Id,  s.stateName as stateName,count(*) AS value from farmers f, states s where "
                . "f.stateID=s.stateID GROUP by s.stateName";
         self::DbConnect();
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function fetchAllDisease() {
        $sql = "SELECT ID, Name, AffectedCrop FROM diseases";
         self::DbConnect();
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function fetchAllFarmers($startpoint, $limit) {
         self::DbConnect();
        $startpoint = self::clean($startpoint);
        $limit = self::clean($limit);
        $sql = "select f.ID ID, f.firstName firstName,f.lastName lastName,f.MSISDN MSISDN,f.sex Sex ,"
                . "l.Name Language from farmers  f, languages l where l.ID=f.languageID";
        $_SESSION['farmerquery'] = $sql;
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    } 
            public static function executeStatement($query,$startpoint, $limit) {
         self::DbConnect();
        $startpoint = self::clean($startpoint);
        $limit = self::clean($limit);
        $sql = $query;
       
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
     public static function fetchStateFarmers($stateID,$startpoint, $limit){
         self::DbConnect();
        $startpoint = self::clean($startpoint);
        $limit = self::clean($limit);
        $stateID = self::clean($stateID);
        $sql = "select f.ID ID, f.firstName firstName,f.lastName lastName,f.MSISDN MSISDN,f.sex Sex ,"
                . "l.Name Language from farmers  f, languages l where l.ID=f.languageID and stateID='$stateID'";
        $_SESSION['farmerquery'] = $sql;
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
     public static function fetchLGAFarmers($lgaID,$startpoint, $limit) {
         self::DbConnect();
        $startpoint = self::clean($startpoint);
        $limit = self::clean($limit);
        $lgaID= self::clean($lgaID);
        $sql = "select f.ID ID, f.firstName firstName,f.lastName lastName,f.MSISDN MSISDN,f.sex Sex ,"
                . "l.Name Language from farmers  f, languages l where l.ID=f.languageID and lgaID='$lgaID'";
        $_SESSION['farmerquery'] = $sql;
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
     public static function fetchFCAFarmers($fcaID,$startpoint, $limit) {
         self::DbConnect();
        $startpoint = self::clean($startpoint);
        $limit = self::clean($limit);
        $fcaID = self::clean($fcaID);
        $sql = "select f.ID ID, f.firstName firstName,f.lastName lastName,f.MSISDN MSISDN,f.sex Sex ,"
                . "l.Name Language from farmers  f, languages l where l.ID=f.languageID and fcaID='$fcaID'";
        $_SESSION['farmerquery'] = $sql;
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
     public static function fetchFUGFarmers($fugID,$startpoint, $limit) {
         self::DbConnect();
        $startpoint = self::clean($startpoint);
        $limit = self::clean($limit);
        $fugID = self::clean($fugID);
        $sql = "select f.ID ID, f.firstName firstName,f.lastName lastName,f.MSISDN MSISDN,f.sex Sex ,"
                . "l.Name Language from farmers  f, languages l where l.ID=f.languageID and fugID='$fugID'";
        $_SESSION['farmerquery'] = $sql;
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
public static function fetchinseason($startpoint, $limit) {
         self::DbConnect();
        $startpoint = self::clean($startpoint);
        $limit = self::clean($limit);
        $sql = "select i.ID ID, c.Name ,i.AccessChannel  ,l.Name Language from in_season  i, languages l, crops c"
                . " where l.ID=i.langID and i.CropID=c.ID order by 2,4";
        $_SESSION['query'] = $sql;
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}";

        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
    public static function fetchAnimalPOPAll($tblName,$startpoint, $limit){
     self::DbConnect();
        $startpoint = self::clean($startpoint);
        $limit = self::clean($limit);
        $tblName = self::clean($tblName);
        $sql = "select i.ID ID, i.AccessChannel  ,l.Name Language from {$tblName}  i, languages l "
                . " where l.ID=i.langID  order by 3 ,2";
        $_SESSION['query'] = $sql;
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}";

        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
}
    public static function fetchpreseason($startpoint, $limit) {
         self::DbConnect();
        $startpoint = self::clean($startpoint);
        $limit = self::clean($limit);
        $sql = "select i.ID ID, c.Name ,i.AccessChannel  ,l.Name Language from pre_season  i, languages l, crops c"
                . " where l.ID=i.langID and i.CropID=c.ID order by 2,4";
        $_SESSION['query'] = $sql;
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}";

        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
    public static function fetchpostseason($startpoint, $limit) {
         self::DbConnect();
        $startpoint = self::clean($startpoint);
        $limit = self::clean($limit);
        $sql = "select i.ID ID, c.Name ,i.AccessChannel  ,l.Name Language from post_season  i, languages l, crops c"
                . " where l.ID=i.langID and i.CropID=c.ID order by 2,4";
        $_SESSION['query'] = $sql;
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}";

        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
    public static function fetchDiseaseDetails($diseaseId) {
         self::DbConnect();
        $diseaseId = self::clean($diseaseId);
        $sql = "SELECT ID, Name, AffectedCrop,Treatment FROM diseases where ID='$diseaseId'";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }

        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function fetchAllcrops() {
        $sql = "SELECT ID, Name, cropDescription FROM crops";
         self::DbConnect();
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function fetchAllMarket($startpoint, $limit) {
         self::DbConnect();
        $startpoint = self::clean($startpoint);
        $limit = self::clean($limit);
        $sql = "SELECT ID, Name, marketAddress  FROM markets";
       $_SESSION['marketquery'] = $sql;
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}"; 
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }public static function fetchStateMarket($stateID,$startpoint, $limit) {
         self::DbConnect();
        $startpoint = self::clean($startpoint);
        $limit = self::clean($limit);
        $stateID = self::clean($stateID);
        $sql = "SELECT ID, Name, marketAddress  FROM markets where stateID='$stateID'";
       $_SESSION['marketquery'] = $sql;
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}"; 
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }public static function fetchLGAMarket($lgaID,$startpoint, $limit) {
         self::DbConnect();
        $startpoint = self::clean($startpoint);
        $limit = self::clean($limit);
        $lgaID = self::clean($lgaID);
        $sql = "SELECT ID, Name, marketAddress  FROM markets where lgaID='$lgaID'";
       $_SESSION['marketquery'] = $sql;
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}"; 
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function fetchMarketDetails($id) {
        $sql = "SELECT m.ID,s.stateName,l.lgaName, m.Name, m.marketAddress, m.marketDay  FROM markets m, states s, lga l "
                . "where m.ID='$id' and s.stateID=m.stateID and l.lgaID=m.lgaID ";
         self::DbConnect();
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
    

    public static function fetchAllAgroDealer() {
        $sql = "SELECT ID, companyName, address  FROM agrobusiness";
         self::DbConnect();
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function fetchCropDetails($cropid) {
         self::DbConnect();
        $cropid = self::clean($cropid);
        $sql = "SELECT ID, Name, cropDescription,cropCycleMonths FROM crops where ID='$cropid'";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }

        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
      public static function fetchinseasonDetails($id) {
         self::DbConnect();
        $id = self::clean($id);
        $sql = "select i.ID ID, c.Name ,i.AccessChannel  ,l.Name Language, i.seedRate,i.seedTreatment,"
                . "i.sowingDate,i.spacing,i.fertilizerApplication,i.weedControl,i.chemicalControl,i.harvesting,"
                . "i.Striga,i.Diseases,i.IntegratedPestManagement,i.storage,i.extra_Info  "
                 . "from in_season  i, languages l, crops c  where l.ID=i.langID and i.CropID=c.ID and i.ID='$id'";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
		mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
	public static function fetchpreseasonDetails($id) {
         self::DbConnect();
        $id = self::clean($id);
        $sql = "select i.ID ID, c.Name ,i.AccessChannel  ,l.Name Language, i.siteSelection,i.landPreparation,"
                . " i.ploughing,i.Harrowing,i.ridging,i.extraInfo1,i.extraInfo2,i.extraInfo3"
                 . " from pre_season  i, languages l, crops c  where l.ID=i.langID and i.CropID=c.ID and i.ID='$id'"; 
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
		mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
	public static function fetchpostseasonDetails($id) {
         self::DbConnect();
        $id = self::clean($id);
        $sql = "select i.ID ID, c.Name ,i.AccessChannel  ,l.Name Language, i.processing,i.delivery,"
                . "i.storage,i.farmBusinessPlaning,i.farmerFinancing,i.rawMaterial,i.extraInfo "
                 . "from post_season  i, languages l, crops c  where l.ID=i.langID and i.CropID=c.ID and i.ID='$id'";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
		mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
    public static function fetchBroadcastDetails($id) {
         self::DbConnect();
        $id = self::clean($id);
        $sql = "SELECT count(*) totalSms from outMessages where broadcastID='$id'";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }

        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function fetchSentSms($id) {
         self::DbConnect();
        $id = self::clean($id);
        $sql = "SELECT count(*) SentSms from outMessages where broadcastID='$id' and statusID=11";
        $result = self::executeQuery($sql);
        $emparray = null;
        while ($row = mysql_fetch_assoc($result)) {
            $emparray = $row['SentSms'];
        }

        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function fetchPendingSms($id) {
         self::DbConnect();
        $id = self::clean($id);
        $sql = "SELECT count(*) PendingSms from outMessages where broadcastID='$id' and statusID=7";
        $result = self::executeQuery($sql);
        $emparray = null;
        while ($row = mysql_fetch_assoc($result)) {
            $emparray = $row['PendingSms'];
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function fetchFarmerDetails($Id) {
         self::DbConnect();
        $Id = self::clean($Id);
        $sql = "SELECT  * FROM farmers where ID='$Id'";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }

        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function fetchFarmerDetails2($Id) {
         self::DbConnect();
        $Id = self::clean($Id);
        $sql = "SELECT ID, firstName,lastName,farmSize,address,MSISDN,phoneType FROM farmers where ID='$Id'";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }

        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function fetchAllPests() {
        $sql = "SELECT ID, Name, pestDescription FROM pests";
         self::DbConnect();
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function fetchPestDetails($pestid) {
         self::DbConnect();
        $pestid = self::clean($pestid);
        $sql = "SELECT ID, Name, pestDescription,pestControl FROM pests where ID='$pestid'";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }

        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function fetchAllHerbs() {
        $sql = "SELECT ID, Name, herb_Usage FROM herbicides";
         self::DbConnect();
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function fetchHerbsDetails($herbid) {
         self::DbConnect();
        $herbid = self::clean($herbid);
        $sql = "SELECT ID, Name, herb_Usage,timing,dosage FROM herbicides where ID='$herbid'";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }

        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function fetchAllfertlizer() {
        $sql = "SELECT ID, Name, fertilizerDescription FROM fertilizers";
         self::DbConnect();
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function fetchfertilizerDetails($fertid) {
         self::DbConnect();
        $fertid = self::clean($fertid);
        $sql = "SELECT ID, Name, fertilizerDescription FROM fertilizers where ID='$fertid'";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }

        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function fetchAllUser($startpoint, $limit) {
         self::DbConnect();
        $startpoint = self::clean($startpoint);
        $limit = self::clean($limit);
        $sql = "SELECT u.ID, s.stateName stateName,u.Name Name,p.UserType UserType FROM states s,users u, privilege p "
                . " where s.stateID=u.State and u.Privilege=p.ID order by s.stateName,u.Name"; 
        $_SESSION['Userquery'] = $sql;
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}"; 
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }  
     public static function fetchUserDetails($id) {
         self::DbConnect();
        $startpoint = self::clean($id);
        $sql = "SELECT u.ID, s.stateName stateName,u.Name Name,p.UserType UserType,u.UserName UserName FROM states s,users u, privilege p "
                . " where s.stateID=u.State and u.Privilege=p.ID  and u.ID='$id' order by s.stateName,u.Name"; 
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
    
      public static function updateuser($msg,$phoneNo,$userId,$password,$header) {
         self::DbConnect();
        $msg = self::clean($msg);
        $phoneNo = self::clean($phoneNo);
        $userId = self::clean($userId);
        $password = self::clean($password);
        $sql = "update users set password='$password'  where  ID='$userId' ";    
        self::executeQuery($sql);
        $sql2=" insert into  outMessages(messageID,messageContent,destAddress,sourceAddress,statusID,dateInserted,no_Of_Retry,max_Send,bucketID,dateModified)  values('','$msg','$phoneNo','$header','7',now(),'0','0','0',now())";
        self::executeQuery($sql2);
    }
         public static function insertUser($state,$usertype,$name,$PhoneNo,$password,$header,$msg) {
         self::DbConnect();
        $state = self::clean($state);
        $usertype = self::clean($usertype);
        $name = self::clean($name);
        $PhoneNo = self::clean($PhoneNo);
        $password = self::clean($password);
        $header = self::clean($header);
        $sql = "insert into users values('','$name', '$state','','','', '$PhoneNo','$password','$usertype') ";    
        self::executeQuery($sql);
        $id=self::fetchuserID($PhoneNo);
        $sql2=" insert into  outMessages(messageID,messageContent,destAddress,sourceAddress,statusID,dateInserted,no_Of_Retry,max_Send,bucketID,dateModified)  values('','$msg','$PhoneNo','$header','7',now(),'0','0','0',now())";
        self::executeQuery($sql2);
        return $id;
    }
     public static function insertMarket($state,$lga,$marketName,$marketAddress,$marketDay) {
         self::DbConnect();
        $state = self::clean($state);
        $lga = self::clean($lga);
        $marketName = self::clean($marketName);
        $marketAddress = self::clean($marketAddress);
        $marketDay = self::clean($marketDay);
        $sql = "insert into markets values('','$marketName', '$marketAddress','0','$lga','$state','$marketDay') ";    
        self::executeQuery($sql);
        $id=  mysql_insert_id();
        return $id;
    }
    public static function updateMarket($id,$state,$lga,$marketName,$marketAddress,$marketDay){
           self::DbConnect();
        $state = self::clean($state);
        $lga = self::clean($lga);
        $marketName = self::clean($marketName);
        $marketAddress = self::clean($marketAddress);
        $marketDay = self::clean($marketDay);
        $id = self::clean($id);
        $sql = "update markets set Name='$marketName',marketAddress='$marketAddress',lgaID='$lga',stateID='$state',marketDay='$marketDay' where ID ='$id'";  
        self::executeQuery($sql);
        
    }
    public static function fetchStateUser($state,$startpoint, $limit) {
         self::DbConnect();
        $startpoint = self::clean($startpoint);
        $limit = self::clean($limit);
        $sql = "SELECT u.ID, s.stateName stateName,u.Name Name,p.UserType UserType FROM states s,users u, privilege p "
                . " where s.stateID=u.State and u.Privilege=p.ID  and u.State='$state'  order by s.stateName,u.Name"; 
        $_SESSION['Userquery'] = $sql;
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}"; 
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
    public static function fetchAllfca($startpoint, $limit) {
         self::DbConnect();
        $startpoint = self::clean($startpoint);
        $limit = self::clean($limit);
        $sql = "SELECT f.ID, s.stateName stateName,l.lgaName lgaName,f.Name FCAName,f.groupLeadName groupLeadName FROM fca f,states s, lga l "
                . " where s.stateID=f.stateID and l.lgaID=f.lgaID order by s.stateName,l.lgaName"; 
        $_SESSION['fcaquery'] = $sql;
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}"; 
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
      public static function fetchStatefcaRec($stateID,$startpoint, $limit) {
         self::DbConnect();
        $startpoint = self::clean($startpoint);
        $limit = self::clean($limit);
         $stateID = self::clean($stateID, $stateID);
        $sql = "SELECT f.ID, s.stateName stateName,l.lgaName lgaName,f.Name FCAName,f.groupLeadName groupLeadName FROM fca f,states s, lga l "
                . "where s.stateID=f.stateID and l.lgaID=f.lgaID and f.stateID='$stateID' order by s.stateName,l.lgaName ";
        $_SESSION['fcaquery'] = $sql;
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
      public static function fetchlgafca($lgaID,$startpoint, $limit) {
         self::DbConnect();
        $startpoint = self::clean($startpoint);
        $limit = self::clean($limit);
        $lgaID = self::clean($lgaID, $lgaID);
        $sql = "SELECT f.ID, s.stateName stateName,l.lgaName lgaName,f.Name FCAName,f.groupLeadName groupLeadName FROM fca f,states s, lga l "
                . "where s.stateID=f.stateID and l.lgaID=f.lgaID and  	f.LgaID='$lgaID' order by s.stateName,l.lgaName ";
        $_SESSION['fcaquery'] = $sql;
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
    public static function fetchFCADetails($id)   {
        $sql = "SELECT f.ID, s.stateName stateName,l.lgaName lgaName,f.Name FCAName,f.groupLeadName groupLeadName, f.groupPhoneNo FROM fca f,states s, lga l "
                . "where f.ID='$id'and  s.stateID=f.stateID and l.lgaID=f.lgaID order by s.stateName,l.lgaName";
         self::DbConnect();
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function fetchAllfug($startpoint,$limit) {
         self::DbConnect();
        $startpoint = self::clean($startpoint);
        $limit = self::clean($limit);
        $sql = "SELECT fu.ID, s.stateName stateName, fa.Name FCAName,fu.Name FUGName,fu.groupLeadName groupLeadName FROM fca fa,states s, fug fu "
                . "where s.stateID=fa.stateID and fa.ID=fu.FCAID order by s.stateName,fa.Name";
        $_SESSION['fugquery'] = $sql;
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
    
       public static function  fetchStatesfug($state, $startpoint, $limit) {
         self::DbConnect();
        $state = self::clean($state);
        $startpoint = self::clean($startpoint);
        $limit = self::clean($limit);
        $sql = "SELECT fu.ID, s.stateName stateName, fa.Name FCAName,fu.Name FUGName,fu.groupLeadName groupLeadName FROM fca fa,states s, fug fu "
                . "where s.stateID=fa.stateID and fa.ID=fu.FCAID  and s.stateID='$state' order by s.stateName,fa.Name "; 
        $_SESSION['fugquery'] = $sql;
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
       public static function fetchlgafug($lgaID,$startpoint,$limit) {
         self::DbConnect();
         $lgaID = self::clean($lgaID);
        $startpoint = self::clean($startpoint);
        $limit = self::clean($limit);
        $sql = "SELECT fu.ID, s.stateName stateName, fa.Name FCAName,fu.Name FUGName,fu.groupLeadName groupLeadName FROM fca fa,states s, fug fu "
                . "where s.stateID=fa.stateID and fa.ID=fu.FCAID and fa.LgaID='$lgaID' order by s.stateName,fa.Name";
        $_SESSION['fugquery'] = $sql;
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
       public static function fetchfcafug($fcaID,$startpoint,$limit) {
         self::DbConnect();
        $fcaID = self::clean($fcaID);
        $startpoint = self::clean($startpoint);
        $limit = self::clean($limit);
        $sql = "SELECT fu.ID, s.stateName stateName, fa.Name FCAName,fu.Name FUGName,fu.groupLeadName groupLeadName FROM fca fa,states s, fug fu "
                . "where s.stateID=fa.stateID and fa.ID=fu.FCAID and fa.ID=$fcaID order by s.stateName,fa.Name";
        $_SESSION['fugquery'] = $sql;
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
    
    

    public static function fetchfugDetails($id) {
        $sql = "SELECT fu.ID, s.stateName stateName, fa.Name FCAName,fu.Name FUGName,fu.groupLeadName groupLeadName, fu.groupPhoneNo groupPhoneNo"
                . " FROM fca fa,states s, fug fu where fu.ID='$id' and s.stateID=fa.stateID and fa.ID=fu.FCAID ";
         self::DbConnect();
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function populateState() {
        $sql = "SELECT stateID , stateName from states";
         self::DbConnect();
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function fetchMessage($msgTitle, $season, $cropID, $langID) {
         self::DbConnect();
        $msgTitle = self::clean($msgTitle);
        $season = self::clean($season);
        $cropID = self::clean($cropID);
        $langID = self::clean($langID);
        $sql = "select {$msgTitle} from {$season} where CropID='$cropID' and accessChannel='Mobile' and langID='$langID'";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_row($result)) {
            $emparray[] = $row[0];
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    } 
public static function fetchLivestockMessage($tblName, $POP, $language) {
         self::DbConnect();
        $POP = self::clean($POP);
        $tblName = self::clean($tblName);
        $langID = self::clean($language);
        $sql = "select {$POP} from  {$tblName} where accessChannel='Mobile' and langID='$langID'"; 
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_row($result)) {
            $emparray[] = $row[0];
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }
    public static function fetchAnimalMessage($msgTitle, $animalID, $langID) {
         self::DbConnect();
        $msgTitle = self::clean($msgTitle);
        $animalID = self::clean($animalID);
        $langID = self::clean($langID);
        $sql = "select {$msgTitle} from {$animalID} where  accessChannel='Mobile' and langID='$langID'";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_row($result)) {
            $emparray[] = $row[0];
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function fetchVegetableMessage($msgTitle, $vegetableID, $langID) {
         self::DbConnect();
        $msgTitle = self::clean($msgTitle);
        $vegetableID = self::clean($vegetableID);
        $langID = self::clean($langID);
        $sql = "select {$msgTitle} from {$vegetableID} where  accessChannel='Mobile' and langID='$langID'";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_row($result)) {
            $emparray[] = $row[0];
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function insertBroadcast($searchCriteria, $searchValue, $description, $stockName, $stockID, $messageTitle, $msgContent, $deliveryDate, $userId) {
         self::DbConnect();
        $searchCriteria = self::clean($searchCriteria);
        $searchValue = self::clean($searchValue);
        $description = self::clean($description);
        $stockName = self::clean($stockName);
        $stockID = self::clean($stockID);
        $messageTitle = self::clean($messageTitle);
        $msgContent = self::clean($msgContent);
        $deliveryDate = self::clean($deliveryDate);
        $userId = self::clean($userId);
        $sql = " insert into  broadcast values('','$searchCriteria','$searchValue','$description','$stockName','$stockID','$messageTitle','$msgContent',now(),'$deliveryDate','7','$userId')";
        self::executeQuery($sql);
        mysql_close();
    }
    public static function insertFCA($state,$lga,$fcaname,$fcaleadername,$fcaleaderPhone) {
         self::DbConnect();
         $lga = self::clean($lga);
        $state = self::clean($state);
        $fcaname = self::clean($fcaname);
        $fcaleadername = self::clean($fcaleadername);
        $fcaleaderPhone = self::clean($fcaleaderPhone);      
        $sql = " insert into  fca values('','$fcaname','$fcaleadername','$fcaleaderPhone','$state','$lga',now())";
        self::executeQuery($sql);
        $id= self::fetchfcaID($fcaleaderPhone) ;
        mysql_close();
        return $id;
    }
	 public static function insertInseason($crop,$access_channel,$languageID,$seed_rate,$seed_treatment,$sowing_date,$spacing,$fertilizer_app,$weed_control,$chemical_control,$harvesting,$striga,$disease,$ipm,$storage,$extra_Info) {
         self::DbConnect();
         $crop = self::clean($crop);
        $access_channel = self::clean($access_channel);
        $languageID = self::clean($languageID);
        $seed_rate = self::clean($seed_rate);
        $seed_treatment = self::clean($seed_treatment);  
		$sowing_date = self::clean($sowing_date);
		$spacing = self::clean($spacing);
        $fertilizer_app = self::clean($fertilizer_app);
        $weed_control = self::clean($weed_control);
        $chemical_control = self::clean($chemical_control);
        $harvesting = self::clean($harvesting); 	
		  $striga = self::clean($striga);  
		$disease = self::clean($disease);
        $ipm = self::clean($ipm);
        $storage = self::clean($storage);
        $extra_Info = self::clean($extra_Info);
        $sql = " insert into  pre_season values('','$languageID','$access_channel','$crop','$seed_rate','$seed_treatment','$sowing_date','$spacing',".
		       "'$fertilizer_app','$weed_control','$chemical_control','$harvesting','$striga','$disease','$ipm','$storage','$extra_Info')"; echo $sql;
        self::executeQuery($sql);
        $id= mysql_insert_id() ;
        mysql_close();
        return $id;
    }
	public static function insertPreseason($crop,$access_channel,$languageID,$site_selection,$land_prep,$ploughing,$harrowing,$ridging,$extra_Info,$extra_Info2,$extra_Info3) {
         self::DbConnect();
         $crop = self::clean($crop);
        $access_channel = self::clean($access_channel);
        $languageID = self::clean($languageID);
        $site_selection = self::clean($site_selection);
        $land_prep = self::clean($land_prep);  
		$ploughing = self::clean($ploughing);
		$harrowing = self::clean($harrowing);
        $ridging = self::clean($ridging);
        $extra_Info = self::clean($extra_Info);
        $extra_Info2 = self::clean($extra_Info2);
        $extra_Info3 = self::clean($extra_Info3); 
        $sql = " insert into  pre_season values('','$languageID','$access_channel','$crop','$site_selection','$land_prep','$ploughing','$harrowing',".
		       "'$ridging','$extra_Info','$extra_Info2','$extra_Info3')"; 
        self::executeQuery($sql);
        $id= mysql_insert_id() ;
        mysql_close();
        return $id;
    }
		public static function insertPostseason($crop,$access_channel,$languageID,$procesing,$bulking_delivery,$storage,$fbp,$ff,$rms,$extra_Info) {
         self::DbConnect();
         $crop = self::clean($crop);
        $access_channel = self::clean($access_channel);
        $languageID = self::clean($languageID);
        $procesing = self::clean($procesing);
        $bulking_delivery = self::clean($bulking_delivery);  
		$storage = self::clean($storage);
		$fbp = self::clean($fbp);
        $ff = self::clean($ff);
        $rms = self::clean($rms);
        $extra_Info = self::clean($extra_Info); 
        $sql = " insert into  post_season values('','$languageID','$access_channel','$crop','$procesing','$bulking_delivery','$storage','$fbp',".
		       "'$ff','$rms','$extra_Info')"; 
        self::executeQuery($sql);
        $id= mysql_insert_id() ;
        mysql_close();
        return $id;
    }
     public static function insertFUG($fca,$fugname,$fugleadername,$fugleaderPhone) {
         self::DbConnect();
         $fca = self::clean($fca);       
        $fugname = self::clean($fugname);
        $fugleadername = self::clean($fugleadername);
        $fugleaderPhone = self::clean($fugleaderPhone);     
        $sql = " insert into  fug values('','$fugname','$fugleadername','$fugleaderPhone',$fca,now())";
        self::executeQuery($sql);
        $id= self::fetchfugID($fugleaderPhone) ;
        mysql_close();
        return $id;
    }   
     public static function UpdateFUG($id,$fca,$fugname,$fugleadername,$fugleaderPhone) {
         self::DbConnect();
         $fca = self::clean($fca);       
        $fugname = self::clean($fugname);
        $fugleadername = self::clean($fugleadername);
        $fugleaderPhone = self::clean($fugleaderPhone);     
        $sql = " update fug set  Name='$fugname',groupLeadName='$fugleadername',groupPhoneNo='$fugleaderPhone',FCAID=$fca where ID='$id'";
        self::executeQuery($sql);
        
        mysql_close();
       
    } 
   public static function UpdateFCA($id,$state,$lga,$fcaname,$fcaleadername,$fcaleaderPhone)
   {
         self::DbConnect();
        $id = self::clean($id);
        $lga = self::clean($lga);
        $state = self::clean($state);
        $fcaname = self::clean($fcaname);
        $fcaleadername = self::clean($fcaleadername);
        $fcaleaderPhone = self::clean($fcaleaderPhone);
        $sql = " update fca set Name ='$fcaname', groupLeadName='$fcaleadername', groupPhoneNo='$fcaleaderPhone', "
                . " stateID='$state',LgaID='$lga' where ID='$id'"; 
        self::executeQuery($sql);
        mysql_close();
   }

    public static function insertFarmer($fName, $lName, $status, $gender, $size, $address, $phoneNo, $language, $phoneType, $market, $fug, $fca, $lga, $state, $crop1, $crop2, $crop3, $animal, $userID) {
         self::DbConnect();
        $fName = self::clean($fName);
        $lName = self::clean($lName);
        $status = self::clean($status);
        $gender = self::clean($gender);
        $size = self::clean($size);
        $address = self::clean($address);
        $phoneNo = self::clean($phoneNo);
        $language = self::clean($language);
        $phoneType = self::clean($phoneType);
        $market = self::clean($market);
        $fug = self::clean($fug);
        $fca = self::clean($fca);
        $lga = self::clean($lga);
        $state = self::clean($state);
        $crop1 = self::clean($crop1);
        $crop2 = self::clean($crop2);
        $crop3 = self::clean($crop3);
        $animal = self::clean($animal);
        $userID = self::clean($userID);
        $sql = " insert into  farmers values('','$language','$state','$lga','$fca','$fug','$fName','$lName','$status','$gender','$size','$address','$phoneNo','$phoneType','$market',now(),now(),'$userID','$userID')";
        
        self::executeQuery($sql);
        
        $id= self::fetchfarmerID($phoneNo) ;
        if ($crop1 != '-1') {
            $sql = "insert into farmercrops values('','$id','$crop1')";
            self::executeQuery($sql);
        }
        if ($crop2 != '-1') {
            $sql = "insert into farmercrops values('','$id','$crop2')";
            self::executeQuery($sql);
        }
        if ($crop3 != '-1') {
            $sql = "insert into farmercrops values('','$id','$crop3')";
            self::executeQuery($sql);
        }
        if ($animal != '-1') {
            $sql = "insert into farmeranimalhusbandry values('','$id','$animal')";
            self::executeQuery($sql);
        }
        mysql_close();
        return $id;
    }
     public static function UpdateFarmer($id,$fName, $lName, $status, $gender, $size, $address, $phoneNo, $language, $phoneType, $market, $fug, $fca, $lga, $state, $crop1, $crop2, $crop3, $animal, $userID) {
         self::DbConnect();
        $id = self::clean($id);
        $fName = self::clean($fName);
        $lName = self::clean($lName);
        $status = self::clean($status);
        $gender = self::clean($gender);
        $size = self::clean($size);
        $address = self::clean($address);
        $phoneNo = self::clean($phoneNo);
        $language = self::clean($language);
        $phoneType = self::clean($phoneType);
        $market = self::clean($market);
        $fug = self::clean($fug);
        $fca = self::clean($fca);
        $lga = self::clean($lga);
        $state = self::clean($state);
        $crop1 = self::clean($crop1);
        $crop2 = self::clean($crop2);
        $crop3 = self::clean($crop3);
        $animal = self::clean($animal);
        $userID = self::clean($userID);
        $sql = "update   farmers set languageID='$language', stateID='$state', lgaID='$lga',fcaID='$fca',fugID='$fug',"
                . " firstName='$fName', lastName='$lName', maritalStatus='$status', sex='$gender',farmSize='$size',"
                . "address='$address',phoneType='$phoneType',marketID='$market',dateModified=now(), modifiedBy='$userID'"
                . " where ID='$id'";
        
        self::executeQuery($sql);
        self::executeQuery("delete from farmercrops where farmerID='$id' ");
        self::executeQuery("delete from farmeranimalhusbandry where farmerID='$id' ");
        if ($crop1 != '-1') {
            $sql = "insert into farmercrops values('','$id','$crop1')";
            self::executeQuery($sql);
        }
        if ($crop2 != '-1') {
            $sql = "insert into farmercrops values('','$id','$crop2')";
            self::executeQuery($sql);
        }
        if ($crop3 != '-1') {
            $sql = "insert into farmercrops values('','$id','$crop3')";
            self::executeQuery($sql);
        }
        if ($animal != '-1') {
            $sql = "insert into farmeranimalhusbandry values('','$id','$animal')";
            self::executeQuery($sql);
        }
        
     
        mysql_close();
        return ;
    }
     public static function fetchfcaID($MSISDN) {
        $MSISDN = self::clean($MSISDN);
        $sql = "select ID from fca where groupPhoneNo='$MSISDN'";
        $result = self::executeQuery($sql);
        $myResult;
        while ($row = mysql_fetch_row($result)) {
            $myResult = $row[0];
        }
        return $myResult;
    }
    public static function fetchfugID($MSISDN) {
        $MSISDN = self::clean($MSISDN);
        $sql = "select ID from fug where groupPhoneNo='$MSISDN'";
        $result = self::executeQuery($sql);
        $myResult;
        while ($row = mysql_fetch_row($result)) {
            $myResult = $row[0];
        }
        return $myResult;
    }
       


    public static function fetchcropName($cropID) {
         self::DbConnect();
        $cropID = self::clean($cropID);
        $sql = "select  Name from crops where ID='$cropID'";
        $result = self::executeQuery($sql);
        $myResult;
        while ($row = mysql_fetch_row($result)) {
            $myResult = $row[0];
        }
        mysql_close();
        mysql_free_result($result);
        return $myResult;
    }

    public static function fetchVegetableName($vegetableID) {
         self::DbConnect();
        $vegetableID = self::clean($vegetableID);
        $sql = "select  name from vegetable where ID='$vegetableID'";

        $result = self::executeQuery($sql);
        $myResult;
        while ($row = mysql_fetch_row($result)) {
            $myResult = $row[0];
        }
        mysql_close();
        mysql_free_result($result);
        return $myResult;
    }

    public static function fetchAnimalName($animalID) {
         self::DbConnect();
        $animalID = self::clean($animalID);
        $sql = "select  Name from animalhusbandry where ID='$animalID'";
        $result = self::executeQuery($sql);
        $myResult;
        while ($row = mysql_fetch_row($result)) {
            $myResult = $row[0];
        }
        mysql_close();
        mysql_free_result($result);
        return $myResult;
    }

    public static function populateLang() {
        $sql = "SELECT ID , Name from languages";
         self::DbConnect();
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function populateCrop() {
        $sql = "SELECT ID , Name from crops";
         self::DbConnect();
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function populateAnimal() {
        $sql = "SELECT ID , Name from animalhusbandry";
         self::DbConnect();
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function populateLivestock() {
        $sql = "SELECT ID , Name from animalhusbandry where category='Livestock'";
         self::DbConnect();
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function populateAquaculture() {
        $sql = "SELECT ID , Name from animalhusbandry where category='Aquaculture'";
         self::DbConnect();
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function populateVegetable() {
        $sql = "SELECT ID , Name from vegetable";
         self::DbConnect();
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function populatelga($stateID) {
         self::DbConnect();
        $stateID = self::clean($stateID);
        $sql = "SELECT lgaID , lgaName from lga where 	stateID='$stateID'";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function populatefca($lga) {
         self::DbConnect();
        $lga = self::clean($lga);
        $sql = "SELECT ID , Name from fca where LgaID='$lga'";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function populatefug($fca) {
         self::DbConnect();
        $fca = self::clean($fca);
        $sql = "SELECT ID , Name from fug where FCAID='$fca'";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function populateMarket($lgaID) {
         self::DbConnect();
        $lgaID = self::clean($lgaID);
        $sql = "SELECT ID , Name from markets where lgaID='$lgaID'";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function populatePOP($season) {
         self::DbConnect();
        $season = self::clean($season);
        $sql = "SELECT * from  {$season}";
        $result = self::executeQuery($sql);
        mysql_close();
        return $result;
    }

    public static function fetchAnimalPOP($animalPOP) {
         self::DbConnect();
        $animalPOP = self::clean($animalPOP);
        $sql = "SELECT * from  {$animalPOP}";
        $result = self::executeQuery($sql);
        mysql_close();
        return $result;
    }

    public static function fetchAllBroadcast($startpoint, $limit) {
         self::DbConnect();
         $startpoint = self::clean($startpoint);
          $limit = self::clean($limit);
        $sql = "SELECT ID,searchCriteria,searchValue,Description,messageTitle,dateInserted "
                . " from broadcast order by 6 desc ";
         $_SESSION['Broadcastquery'] = $sql;
        $sql = $sql . "  LIMIT {$startpoint} , {$limit}";
        $result = self::executeQuery($sql);
        $emparray = array();
        while ($row = mysql_fetch_assoc($result)) {
            $emparray[] = $row;
        }
        mysql_close();
        mysql_free_result($result);
        return $emparray;
    }

    public static function clean($string) {
        $detagged = strip_tags($string);
        $stripped = stripslashes($detagged);
        $escaped = trim(mysql_real_escape_string($stripped));
        return $escaped;
    }

}

?>